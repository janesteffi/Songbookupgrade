from django.shortcuts import render
from django.http import HttpResponse
from .models import songlist

# Create your views here.

def home(request):
    songs=songlist.objects.all()
    return render(request,'home.html', {"songlist":songs})