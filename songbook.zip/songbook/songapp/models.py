from django.db import models
from django.db import connections

# Create your models here.

class songlist(models.Model):
    Song_Name =models.CharField(max_length=100)
    Song_Number =models.CharField(max_length=100)
    
class Meta:
    db_table="song_lists"
    
    