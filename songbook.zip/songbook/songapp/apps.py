from django.apps import AppConfig


class SongappConfig(AppConfig):
    name = 'songapp'
